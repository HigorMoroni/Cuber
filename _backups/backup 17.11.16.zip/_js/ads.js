var sorte;
	sorte=getRandom(3);
document.write ('<img src="_imagens/ads/'+parseInt(sorte)+'.png">');
function getRandom(max) {
    return Math.floor(Math.random() * max + 1)
}