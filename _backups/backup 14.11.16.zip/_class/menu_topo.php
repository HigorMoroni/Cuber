<?php
echo
'<nav class="menu">
	<ul type="disc">
		<li><a href="ajuda.php">AJUDA</a></li> | 
		<li><a href="cadastro.php">CADASTRE-SE</a></li>
		<li id="caixa"><a id="botaoEntrar" href="login.php">ENTRAR</a></li>
	</ul>
</nav>'
?>