<?php
echo
'<div id="inicio">
	<img id="inicial" src="_imagens/carona.jpg"/>
	<div id="flutuante"><a href="cadastro.php"><img id="opcaoFlutuante" src="_imagens/comece.png"/></a></div>
</div>'
?>