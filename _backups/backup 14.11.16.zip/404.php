<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="UTF-8"/>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>CUBER - Pagina não encontrada</title>
        <link rel="stylesheet" type="text/css" href="_css/estilo.css"/>
        <link rel="icon" href="_imagens/favicon.ico" type="image/x-icon">
        <link rel="shortcut icon" href="_imagens/favicon.ico" type="image/x-icon">
        <link rel="shortcut icon" href="_imagens/favicon.ico" type="image/vnd.microsoft.icon">
    </head>
    <body>
        <?php include "_class/menu_topo.php"?>
        <section class="tudo">
        <?php include "_class/header.php"?>
        <div class="corpo">
			<center><img src="_imagens/erro404.png" title="Image: _imagens/erro404.png"><br></center>
        </div>
        </section>
        <?php include "_class/footer.php"?>
    </body>
</html>