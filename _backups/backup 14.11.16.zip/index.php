<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<meta charset="UTF-8"/>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>CUBER - Caronas Universitárias da Baixada e Região</title>
		<link rel="stylesheet" type="text/css" href="_css/estilo.css"/>
    	<link rel="icon" href="_imagens/favicon.ico" type="image/x-icon">
    	<link rel="shortcut icon" href="_imagens/favicon.ico" type="image/x-icon">
    	<link rel="shortcut icon" href="_imagens/favicon.ico" type="image/vnd.microsoft.icon">
	</head>
	<body>
        <?php include "_class/menu_topo.php"?>
		<section class="tudo">
            <?php include "_class/header.php"?>
            <?php include "_class/imagens_inicio.php"?>
			<div class="corpo">
				<h2>Saiba Mais</h2>
				<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris id augue in magna mollis mollis ac sit amet tortor. Donec vitae dolor metus. Nam iaculis enim ante, in auctor nisi aliquam eu. Donec ut mauris magna. Phasellus auctor eros sit amet velit gravida, quis efficitur turpis rutrum. Phasellus vestibulum est auctor diam efficitur consequat. Quisque id vehicula eros. Cras urna tellus, commodo in maximus vel, interdum ut neque. Ut fermentum ante ut turpis consequat, eu efficitur augue posuere. Duis quis magna imperdiet, dignissim ante vel, elementum mi. Duis sed ornare magna, et laoreet ex. Etiam vel mauris urna.</p>
				<p>Mauris dapibus ullamcorper felis nec tristique. Fusce accumsan, massa in cursus tincidunt, nibh dui ultricies elit, nec consectetur arcu nibh nec lorem. In rutrum nulla eget odio tempus, id iaculis lorem ultrices. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus eget nulla quis magna tristique interdum eu sit amet erat. Sed rutrum arcu nec nulla sagittis, sed vulputate enim vestibulum. Praesent pharetra elit quis dui condimentum, a imperdiet lorem laoreet. Pellentesque volutpat lacus magna, eget laoreet nulla efficitur quis. Praesent et convallis elit. Aenean id justo a tellus rutrum vehicula.</p>
				<p>Aliquam erat volutpat. Curabitur et lectus rutrum velit luctus sollicitudin. Morbi nibh sapien, elementum ut enim sed, venenatis viverra lacus. Pellentesque eu vulputate augue. Ut fringilla condimentum mauris sed volutpat. Duis tortor lectus, elementum ut metus id, ultricies gravida lorem. Nulla finibus velit sed ultrices fermentum. Vivamus vulputate semper metus, ut consequat ex. Suspendisse finibus tristique pellentesque. Aliquam blandit dolor augue, et volutpat orci mollis a. Aenean sed orci id metus fringilla bibendum. Donec nulla lorem, mollis eget vehicula eu, consectetur at mi. Curabitur tristique ultricies nisi. Cras et erat id ex facilisis imperdiet. Integer posuere aliquet metus, in porttitor velit rutrum in. Nullam accumsan purus sodales, tempor ante vitae, tincidunt est.</p>
				<p>Sed malesuada orci eu lobortis accumsan. Aenean mauris mauris, sagittis lacinia feugiat non, condimentum eget diam. Maecenas lobortis sagittis nisl sed congue. Curabitur in lacinia nulla, consequat tincidunt sem. Fusce pulvinar urna sed quam varius suscipit. Praesent vestibulum dapibus metus ac dignissim. Nullam non urna eros. Phasellus ornare quam aliquam ornare efficitur. Suspendisse et arcu sed eros semper tempor ut et tortor. Aenean tempus suscipit augue a interdum. Duis sollicitudin metus arcu, at efficitur ligula pellentesque consequat.</p>
				<p>Quisque sed eros sed est vehicula viverra. Nunc dignissim justo at orci finibus ornare id vel felis. Proin pretium porttitor nibh. Etiam id aliquet mauris. Pellentesque pellentesque tempus cursus. Aliquam sed neque magna. Donec vel lorem vitae dolor dictum fringilla vel vitae ligula. Aenean mollis non lorem nec varius. Quisque non ultrices dolor. Proin placerat scelerisque libero, varius tempor eros posuere vel. Proin fringilla, erat non faucibus rhoncus, nisi sem sagittis risus, id scelerisque nisi felis eget felis.</p>
			</div>
		</section>
		<?php include "_class/footer.php"?>
	</body>
</html>