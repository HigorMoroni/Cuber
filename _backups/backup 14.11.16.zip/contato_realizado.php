<!DOCTYPE html>
<html lang="pt-br" xmlns:b="http://www.w3.org/1999/XSL/Transform">
	<head>
		<meta charset="UTF-8"/>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>CUBER - Contato</title>
		<link rel="stylesheet" type="text/css" href="_css/estilo.css"/>
    	<link rel="icon" href="_imagens/favicon.ico" type="image/x-icon">
    	<link rel="shortcut icon" href="_imagens/favicon.ico" type="image/x-icon">
    	<link rel="shortcut icon" href="_imagens/favicon.ico" type="image/vnd.microsoft.icon">
	</head>
	<body>
        <?php include "_class/menu_topo.php"?>
		<section class="tudo">
            <?php include "_class/header.php"?>
			<div class="corpo">
                <h2>Seu contato foi realizado com sucesso.<br>
                    Nós da Cuber agradecemos a sua preferência.
                    Responderemos em breve!</h2>
            </div>
		</section>
		<?php include "_class/footer.php"?>
	</body>
</html>
