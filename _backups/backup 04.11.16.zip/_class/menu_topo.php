<?php
echo
'<nav class="menu">
	<ul type="disc">
		<li><a href="ajuda.html">AJUDA</a></li> | 
		<li><a href="cadastro.html">CADASTRE-SE</a></li>
		<li id="caixa"><a id="botaoEntrar" href="login.html">ENTRAR</a></li>
	</ul>
</nav>'
?>