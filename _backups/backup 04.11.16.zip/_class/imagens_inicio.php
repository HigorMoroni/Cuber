<?php
echo
'<div id="inicio">
	<img id="inicial" src="_imagens/carona.jpg"/>
	<div id="flutuante"><img id="opcaoFlutuante" src="_imagens/comece.png"/></div>
</div>'
?>