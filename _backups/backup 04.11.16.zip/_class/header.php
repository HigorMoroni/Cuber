<?php
echo
'<header class="cabecalho">
	<a href="index.html"><img id="logo" src="_imagens/logo.jpg"></a><br/>
	<a id="slogan">Porque tempo é dinheiro</a>
</header>'
?>