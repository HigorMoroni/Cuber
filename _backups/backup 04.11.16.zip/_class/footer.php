<?php
echo
'<footer class="rodape">
    <div id="f1">
        <nav class="menu2">
            <ul type="disc">
                <li><a href="cadastro.html">CADASTRO</a></li>
                <li><a href="login.html">ENTRAR</a></li>
            </ul>
        </nav>
        <h1>CUBER</h1>
    </div>
    <div id="f2">
        <table id="links" width="50%">
            <tr>
                <td><a href="viajar.html">Viajar</a></td>
                <td><a href="nossa_historia.html">Nossa História</a></td>
            </tr>
            <tr>
                <td><a href="dirigir.html">Dirigir</a></td>
                <td><a href="ajuda.html">Ajuda</a></td>
            </tr>
            <tr>
                <td><a href="seguranca.html">Segurança</a></td>
                <td><a href="noticias.html">Notícias</a></td>
            </tr>
        </table>
        <img id="redes" src="_imagens/redes.png" alt="" usemap="#Map"/>
        <map name="Map" id="mapRedes">
            <area alt="" title="" target="_blank" href="http://www.instagram.com/cuber" shape="rect" coords="32,16,75,56" />
            <area alt="" title="" target="_blank" href="http://www.facebook.com/cuber" shape="rect" coords="124,135,151,92" />
            <area alt="" title="" target="_blank" href="http://www.youtube.com/cuber" shape="rect" coords="36,100,61,126" />
            <area alt="" title="" target="_blank" href="http://www.twitter.com/cuber" shape="rect" coords="117,58,173,16" />
        </map>
    </div>
    <div id="f3">
        <a href="privacidade.html"><img id="letrinhas1" src="_imagens/letrinhas1.png"></a>
        <a target="_blank" href="http://www.appstore.com"><img class="store" src="_imagens/app_store.png"/></a>
        <a target="_blank" href="http://www.play.google.com/store"><img class="store" src="_imagens/google_play.png"/></a>
        <a target="_blank" href="http://www.microsoftstore.com"><img class="store" src="_imagens/windows_store.png"/></a>
        <img id="letrinhas2" src="_imagens/letrinhas2.png">
    </div>
</footer>'
?>